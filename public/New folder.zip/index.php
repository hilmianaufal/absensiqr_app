<?php

use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

if (file_exists($maintenance = __DIR__.'/../absensi_app/storage/framework/maintenance.php')) {
    require $maintenance;
}

require __DIR__.'/../absensi_app/vendor/autoload.php';

$app = require_once __DIR__.'/../absensi_app/bootstrap/app.php';

// ✅ Tambahin ini: paksa public_path() = folder subdomain (tempat index.php)
$app->usePublicPath(__DIR__);

$app->handleRequest(Request::capture());
